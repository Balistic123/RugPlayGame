function t(n){return typeof n=="function"}export{t as i};
