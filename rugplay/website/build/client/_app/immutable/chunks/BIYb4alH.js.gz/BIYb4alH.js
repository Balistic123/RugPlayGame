import{s as e,p as t}from"./BnkorlfL.js";const s={get route(){return t.route},get status(){return t.status},get url(){return t.url}};e.updated.check;export{s as p};
