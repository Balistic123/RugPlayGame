import{p as t,m as z,r as S,a as h,c as j}from"./BiLdCT7w.js";import{p as C,c as I,s as y,j as A,r as B,t as u,a as q,i as D,g as m}from"./Dc9Cd6uL.js";import{a as E,b as g}from"./aor5dgAF.js";import{e as F,i as G,a as H}from"./DT6MbhOo.js";/**
 * @license @lucide/svelte v0.482.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 */const J={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var K=z("<svg><!><!></svg>");function R(f,e){C(e,!0);const v=t(e,"color",3,"currentColor"),s=t(e,"size",3,24),r=t(e,"strokeWidth",3,2),k=t(e,"absoluteStrokeWidth",3,!1),b=t(e,"iconNode",19,()=>[]),w=S(e,["$$slots","$$events","$$legacy","name","color","size","strokeWidth","absoluteStrokeWidth","iconNode","children"]);var o=K();let i;var n=I(o);F(n,17,b,G,(a,l)=>{let W=()=>m(l)[0],N=()=>m(l)[1];var c=j(),p=D(c);H(p,W,!0,(x,L)=>{let d;u(()=>d=g(x,d,{...N()}))}),h(a,c)});var _=y(n);E(_,()=>e.children??A),B(o),u(a=>i=g(o,i,{...J,...w,width:s(),height:s(),stroke:v(),"stroke-width":a,class:["lucide-icon lucide",e.name&&`lucide-${e.name}`,e.class]}),[()=>k()?Number(r())*24/Number(s()):r()]),h(f,o),q()}export{R as I};
