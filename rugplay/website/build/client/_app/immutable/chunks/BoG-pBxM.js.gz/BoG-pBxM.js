const I=1048576,T=100;const E=1e3,_=1100;export{T as C,E as I,I as M,_ as T};
