import{h as t,l as e}from"./Dc9Cd6uL.js";function r(n){t(()=>e(()=>n()))}export{r as o};
