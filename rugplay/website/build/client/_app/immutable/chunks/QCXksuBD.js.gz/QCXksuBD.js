import{p}from"./BIYb4alH.js";const o=p;export{o as p};
